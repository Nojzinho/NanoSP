Hey, this is the readme file of NanoSP - Simple Spawner for FiveM.

The code is fully editable and also usable for personal benefits. Made with lua 5.4.

I don't mind credit tho ;)

-------------------------------------------------------------------------------------

<your server's folder>\resources\ - here you drag the NanoSP folder from the zip file

open server.cfg and insert:

"ensure NanoSP"

Your done. Enjoy.

-----------------

USAGE: 

/v <vehicle name> <color(optional)> | https://docs.fivem.net/docs/game-references/vehicle-models/, https://wiki.rage.mp/index.php?title=Vehicle_Colors

/ped <ped model name> | https://docs.fivem.net/docs/game-references/ped-models/

/w <weapon name> | https://gtahash.ru/weapons/?page=2