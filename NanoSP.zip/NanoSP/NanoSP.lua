-- /V PARANCS

RegisterCommand("v", function(source, args, rawCommand)
    local playerPed = GetPlayerPed(-1)
    local vehicle = GetVehiclePedIsIn(playerPed, false)

    if DoesEntityExist(vehicle) then
        DeleteVehicle(vehicle)
    end

    if #args < 1 then
        TriggerEvent("chatMessage", "^1USAGE: ^0/v <model name> [color (optional)]")
        return
    end

    local modelName = args[1]
    local vehicleHash = GetHashKey(modelName)

    if not IsModelInCdimage(vehicleHash) or not IsModelAVehicle(vehicleHash) then
        TriggerEvent("chatMessage", "^1ERROR: ^0The entered model name '" .. modelName .. "' doesn't match an actual one.")
        return
    end

    RequestModel(vehicleHash)

    while not HasModelLoaded(vehicleHash) do
        Wait(500)
    end

    local pos = GetEntityCoords(playerPed)
    local heading = GetEntityHeading(playerPed)

    local spawnedVehicle = CreateVehicle(vehicleHash, pos.x, pos.y, pos.z, heading, true, false)

    if DoesEntityExist(spawnedVehicle) then
        local vehicleName = GetDisplayNameFromVehicleModel(vehicleHash)
        local vehicleLabel = GetLabelText(vehicleName)

        -- Put the player into the spawned vehicle
        TaskWarpPedIntoVehicle(playerPed, spawnedVehicle, -1)

        -- Check if a color is provided, otherwise set a random color
        local color = tonumber(args[2]) or math.random(0, 159)

        -- Set the vehicle color
        SetVehicleColours(spawnedVehicle, color, color)

        TriggerEvent("chatMessage", "^2SUCCESS: ^0Spawned the vehicle model: ^5'" .. vehicleLabel .. "'^0, with the color: ^3" .. color .."^0.")
    else
        TriggerEvent("chatMessage", "^1ERROR: ^0Failed to spawn the vehicle.")
    end
end, false)

-- /PED PARANCS

RegisterCommand("ped", function(source, args, rawCommand)
    local playerPed = GetPlayerPed(-1)

    if #args ~= 1 then
        TriggerEvent("chatMessage", "^1USAGE: ^0/ped <ped model>")
        return
    end

    local modelName = args[1]

    if not IsModelInCdimage(modelName) or not IsModelAVehicle(modelName) then
        TriggerEvent("chatMessage", "^1ERROR: ^0The entered ped model '" .. modelName .. "' doesn't match an actual one.")
        return 0
    end

    RequestModel(modelName)

    while not HasModelLoaded(modelName) do
        Wait(500)
    end

    local pos = GetEntityCoords(playerPed)

    SetPlayerModel(PlayerId(), GetHashKey(modelName))
    SetModelAsNoLongerNeeded(GetHashKey(modelName))

    SetEntityCoords(playerPed, pos.x, pos.y, pos.z, false, false, false, true)

    TriggerEvent("chatMessage", "^2SUCCESS: ^0Changed your ped model to: ^5'" .. modelName .. "'^0.")
end, false)

-- /W PARANCS

local weaponNames = {
    ["knife"] = GetHashKey("WEAPON_KNIFE"),
    ["knuckle"] = GetHashKey("WEAPON_KNUCKLE"),
    ["nightstick"] = GetHashKey("WEAPON_NIGHTSTICK"),
    ["hammer"] = GetHashKey("WEAPON_HAMMER"),
    ["bat"] = GetHashKey("WEAPON_BAT"),
    ["golfclub"] = GetHashKey("WEAPON_GOLFCLUB"),
    ["crowbar"] = GetHashKey("WEAPON_CROWBAR"),
    ["bottle"] = GetHashKey("WEAPON_BOTTLE"),
    ["dagger"] = GetHashKey("WEAPON_DAGGER"),
    ["hatchet"] = GetHashKey("WEAPON_HATCHET"),
    ["machete"] = GetHashKey("WEAPON_MACHETE"),
    ["flashlight"] = GetHashKey("WEAPON_FLASHLIGHT"),
    ["switchblade"] = GetHashKey("WEAPON_SWITCHBLADE"),
    ["proxmine"] = GetHashKey("WEAPON_PROXMINE"),
    ["bzgas"] = GetHashKey("WEAPON_BZGAS"),
    ["smokegrenade"] = GetHashKey("WEAPON_SMOKEGRENADE"),
    ["molotov"] = GetHashKey("WEAPON_MOLOTOV"),
    ["fireextinguisher"] = GetHashKey("WEAPON_FIREEXTINGUISHER"),
    ["petrolcan"] = GetHashKey("WEAPON_PETROLCAN"),
    ["hazardcan"] = GetHashKey("WEAPON_HAZARDCAN"),
    ["snowball"] = GetHashKey("WEAPON_SNOWBALL"),
    ["flare"] = GetHashKey("WEAPON_FLARE"),
    ["ball"] = GetHashKey("WEAPON_BALL"),
    ["revolver"] = GetHashKey("WEAPON_REVOLVER"),
    ["poolcue"] = GetHashKey("WEAPON_POOLCUE"),
    ["pipewrench"] = GetHashKey("WEAPON_PIPEWRENCH"),
    ["pistol"] = GetHashKey("WEAPON_PISTOL"),
    ["pistol_mk2"] = GetHashKey("WEAPON_PISTOL_MK2"),
    ["combatpistol"] = GetHashKey("WEAPON_COMBATPISTOL"),
    ["appistol"] = GetHashKey("WEAPON_APPISTOL"),
    ["pistol50"] = GetHashKey("WEAPON_PISTOL50"),
    ["sns pistol"] = GetHashKey("WEAPON_SNSPISTOL"),
    ["heavypistol"] = GetHashKey("WEAPON_HEAVYPISTOL"),
    ["vintagepistol"] = GetHashKey("WEAPON_VINTAGEPISTOL"),
    ["stungun"] = GetHashKey("WEAPON_STUNGUN"),
    ["flaregun"] = GetHashKey("WEAPON_FLAREGUN"),
    ["marksmanpistol"] = GetHashKey("WEAPON_MARKSMANPISTOL"),
    ["microsmg"] = GetHashKey("WEAPON_MICROSMG"),
    ["minismg"] = GetHashKey("WEAPON_MINISMG"),
    ["smg"] = GetHashKey("WEAPON_SMG"),
    ["smg_mk2"] = GetHashKey("WEAPON_SMG_MK2"),
    ["assaultsmg"] = GetHashKey("WEAPON_ASSAULTSMG"),
    ["mg"] = GetHashKey("WEAPON_MG"),
    ["combatmg"] = GetHashKey("WEAPON_COMBATMG"),
    ["combatmg_mk2"] = GetHashKey("WEAPON_COMBATMG_MK2"),
    ["combatpdw"] = GetHashKey("WEAPON_COMBATPDW"),
    ["gusenberg"] = GetHashKey("WEAPON_GUSENBERG"),
    ["machinepistol"] = GetHashKey("WEAPON_MACHINEPISTOL"),
    ["assaultrifle"] = GetHashKey("WEAPON_ASSAULTRIFLE"),
    ["assaultrifle_mk2"] = GetHashKey("WEAPON_ASSAULTRIFLE_MK2"),
    ["carbinerifle"] = GetHashKey("WEAPON_CARBINERIFLE"),
    ["carbinerifle_mk2"] = GetHashKey("WEAPON_CARBINERIFLE_MK2"),
    ["advancedrifle"] = GetHashKey("WEAPON_ADVANCEDRIFLE"),
    ["specialcarbine"] = GetHashKey("WEAPON_SPECIALCARBINE"),
    ["bullpuprifle"] = GetHashKey("WEAPON_BULLPUPRIFLE"),
    ["compactrifle"] = GetHashKey("WEAPON_COMPACTRIFLE"),
    ["pumpshotgun"] = GetHashKey("WEAPON_PUMPSHOTGUN"),
    ["sweepershotgun"] = GetHashKey("WEAPON_SWEEPERSHOTGUN"),
    ["sawnoffshotgun"] = GetHashKey("WEAPON_SAWNOFFSHOTGUN"),
    ["bullpupshotgun"] = GetHashKey("WEAPON_BULLPUPSHOTGUN"),
    ["assaultshotgun"] = GetHashKey("WEAPON_ASSAULTSHOTGUN"),
    ["musket"] = GetHashKey("WEAPON_MUSKET"),
    ["heavyshotgun"] = GetHashKey("WEAPON_HEAVYSHOTGUN"),
    ["dbshotgun"] = GetHashKey("WEAPON_DBSHOTGUN"),
    ["sniperrifle"] = GetHashKey("WEAPON_SNIPERRIFLE"),
    ["heavysniper"] = GetHashKey("WEAPON_HEAVYSNIPER"),
    ["heavysniper_mk2"] = GetHashKey("WEAPON_HEAVYSNIPER_MK2"),
    ["marksmanrifle"] = GetHashKey("WEAPON_MARKSMANRIFLE"),
    ["grenadelauncher"] = GetHashKey("WEAPON_GRENADELAUNCHER"),
    ["grenadelauncher_smoke"] = GetHashKey("WEAPON_GRENADELAUNCHER_SMOKE"),
    ["rpg"] = GetHashKey("WEAPON_RPG"),
    ["minigun"] = GetHashKey("WEAPON_MINIGUN"),
    ["firework"] = GetHashKey("WEAPON_FIREWORK"),
    ["railgun"] = GetHashKey("WEAPON_RAILGUN"),
    ["hominglauncher"] = GetHashKey("WEAPON_HOMINGLAUNCHER"),
    ["grenade"] = GetHashKey("WEAPON_GRENADE"),
    ["stickybomb"] = GetHashKey("WEAPON_STICKYBOMB"),
    ["compactlauncher"] = GetHashKey("WEAPON_COMPACTLAUNCHER"),
    ["snspistol_mk2"] = GetHashKey("WEAPON_SNSPISTOL_MK2"),
    ["revolver_mk2"] = GetHashKey("WEAPON_REVOLVER_MK2"),
    ["doubleaction"] = GetHashKey("WEAPON_DOUBLEACTION"),
    ["specialcarbine_mk2"] = GetHashKey("WEAPON_SPECIALCARBINE_MK2"),
    ["bullpuprifle_mk2"] = GetHashKey("WEAPON_BULLPUPRIFLE_MK2"),
    ["pumpshotgun_mk2"] = GetHashKey("WEAPON_PUMPSHOTGUN_MK2"),
    ["marksmanrifle_mk2"] = GetHashKey("WEAPON_MARKSMANRIFLE_MK2"),
    ["raypistol"] = GetHashKey("WEAPON_RAYPISTOL"),
    ["raycarbine"] = GetHashKey("WEAPON_RAYCARBINE"),
    ["rayminigun"] = GetHashKey("WEAPON_RAYMINIGUN"),
    ["digiscanner"] = GetHashKey("WEAPON_DIGISCANNER"),
    ["navyrevolver"] = GetHashKey("WEAPON_NAVYREVOLVER"),
    ["ceramicpistol"] = GetHashKey("WEAPON_CERAMICPISTOL"),
    ["stonehatchet"] = GetHashKey("WEAPON_STONE_HATCHET"),
    ["pipebomb"] = GetHashKey("WEAPON_PIPEBOMB"),
    ["parachute"] = GetHashKey("GADGET_PARACHUTE"),
    ["gadgetpistol"] = GetHashKey("WEAPON_GADGETPISTOL"),
    ["militaryrifle"] = GetHashKey("WEAPON_MILITARYRIFLE"),
    ["combatshotgun"] = GetHashKey("WEAPON_COMBATSHOTGUN"),
    ["autoshotgun"] = GetHashKey("WEAPON_AUTOSHOTGUN"),
}

RegisterCommand("w", function(source, args, rawCommand)
    local playerPed = GetPlayerPed(-1)

    if #args ~= 1 then
        TriggerEvent("chatMessage", "^1USAGE: ^0/w <weapon model>")
        return
    end

    local weaponName = string.lower(args[1])

    local weaponHash = weaponNames[weaponName]
    if not weaponHash then
        TriggerEvent("chatMessage", "^1ERROR: ^0The entered weapon model ^1'" .. weaponName .. "'^0 doesn't match an actual one.")
        return
    end

    if HasPedGotWeapon(playerPed, weaponHash, false) then
        TriggerEvent("chatMessage", "^1ERROR: ^0You already own the weapon: ^5'" .. weaponName .."'^0.")
        return
    end

    GiveWeaponToPed(playerPed, weaponHash, 100, false, false)

    TriggerEvent("chatMessage", "^2SUCCESS: ^0Weapon given: ^5'" .. weaponName .."'^0.")
end, false)