fx_version 'cerulean'
game 'gta5'
lua54 'yes'

client_script 'NanoSP.lua'